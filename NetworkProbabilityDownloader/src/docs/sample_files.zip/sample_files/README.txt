
In folders.txt comment lines exist that begin with the "#" character.  These lines are ignored by the 'ADD STUDY' process.  Be careful not to remove these characters unless you remove the complete comment line.


